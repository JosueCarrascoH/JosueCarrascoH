<script setup>
import HelloWorld from './components/HelloWorld.vue'
import TheWelcome from './components/TheWelcome.vue'
import Payments from './components/Payments.vue'
import Reserve from './components/Reserve.vue'

</script>

<template>
  <main>
<div class="contenido">
    <Reserve class="caja"/>
    <Payments class="caja"/>
</div>
  </main>


</template>

<style>
*{
  margin: 0;
  padding: 0;
}
.contenido{
  width: 750px;
  padding: 50px;
  position: absolute;
  top: 40%;
  left: 50%;
  transform: translate(-50%, -50%);
}
.caja{
  display: table-cell;
  padding: 20px;
}
</style>
