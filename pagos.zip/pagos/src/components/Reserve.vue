<script>


</script>

<template>
  <div>
    <h1>Reserve la Fecha y hora de visita del técnico/taller</h1>

    <form name="form" id="form" >
      <p>
        Fecha: <input type="date" name="name" placeholder="Nombres y Apellidos" class="form-control"/>
      </p>
      <p>
        Hora: <input type="time" size=36  name="card" placeholder="N de tarjeta" class="form-control" />
      </p>
    </form>
    <h1>Brindenos informacion acerca del problema técnico:</h1>
    <p>
      <textarea name="msg" id="msg" cols="60" rows="10" placeholder="Escribe una descripcion" class="form-control"/>
    </p>
  </div>
</template>

<style scoped>
input{
  margin-left: 20px;
  margin-bottom: 10px;
}
</style>
