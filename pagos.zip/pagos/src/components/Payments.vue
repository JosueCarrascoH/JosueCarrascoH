<script>
export default{
  name: 'Payments',
  data(){
    return{
      contact:{
        name:'',
        card:'',
        ccv:'',
        expiration:'',
        mail:'',
      }
    }
  }
}


</script>

<template>
<div>
  <h1>Seleccione el metodo de pago</h1>
  <h2> <input type="checkbox"> Pago con efectivo</h2>

  <h2> <input type="checkbox"> Pago con tarjeta de crédito</h2>

  <form name="form" id="form" >
    <p>
      <input type="text" size=36 name="name" placeholder="Nombres y Apellidos" class="form-control" v-model="contact.name"/>
    </p>
    <p>
      <input type="text" size=36  name="card" placeholder="N de tarjeta" class="form-control" v-model="contact.card"/>
    </p>
    <p>
      <input type="text" size=14 name="ccv" placeholder="CCV" class="form-control" v-model="contact.ccv"/>

      <input type="text" size=14 name="expiration" placeholder="F. Vencimiento" class="form-control" v-model="contact.expiration"/>
    </p>
    <p>
      <input type="text" size=36 name="mail" placeholder="Correo" class="form-control" v-model="contact.mail"/>
    </p>

    <input type="submit" value="Reservar" title="Reservar" class="btn btn-primary" />
  </form>
</div>
</template>

<style scoped>
input{
  margin-left: 20px;
  margin-bottom: 10px;
}
h2{
  font-size: 20px;
}
</style>
